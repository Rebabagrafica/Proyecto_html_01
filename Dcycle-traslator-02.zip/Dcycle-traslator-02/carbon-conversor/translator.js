const burguerFactor = 0.19305019;
const tshirtsFactor = 0.04436557;
const treesFactor = 0.03584229;
const viajesFactor = 0.00030672;
const bitcoinFactor = 0.015625;
const tvFactor = 18.1818182;

function calcularCO2() {
        var usercarbon = document.getElementById("carbonNumber").value;
        document.getElementById("dinamicAguacate").innerHTML = usercarbon*burguerFactor + " Uds.";
        document.getElementById("dinamicArboles").innerHTML = usercarbon*treesFactor + " Uds.";
        document.getElementById("dinamicTshirt").innerHTML = usercarbon*tshirtsFactor + " Uds.";
        document.getElementById("dinamicViajes").innerHTML = usercarbon*viajesFactor + " Uds.";
        document.getElementById("dinamicBitcoin").innerHTML = usercarbon*bitcoinFactor + " Uds.";
        document.getElementById("dinamicTv").innerHTML = usercarbon*tvFactor + " Uds.";
        console.log("Maybe you're the developer we're looking for? You can reach us at hello@dcycle.io")
}

const explicacionArboles =  "Cada palmera absorbe una cantidad de 27,9 kg de dióxido de carbono al año.";
const explicacionAguacates =  "Una cheeseburger normal produce 5.18 kg de CO2 eq. según un estudio realizado por Open the future.";
const explicacionCamisetas = "La producción de una camiseta de algodón emite 22.54 kg de CO2.";
const explicacionBitcoin = "Un Iphone 13 produce 64 kg de carbono, según el informe de responsabilidad ambiental de Apple.";
const explicacionViajes = "Una furgoneta diesel emite 0,1612 kg de CO2 por km. En un viaje de 19.292 km se emitirán 3.260,35 kg de CO2.";
const explicacionTV = "Una hora de ‘streaming’ emite 55 g de CO2 a la atmósfera según un estudio del portal WebSiteToolTester."; 
const txtBtnDown = "-";

function explainArboles() {
    var textoArboles = document.getElementById("explainArboles");
    if (textoArboles.innerText === "") {
        textoArboles.innerText = explicacionArboles;
    } else {
        textoArboles.innerText = "";
    }
}

function btnArb () {
    var txtBtnOriginal = document.getElementById("botonArboles");
    if (txtBtnOriginal.innerText === "+") {
        txtBtnOriginal.innerText = txtBtnDown;
    } else {
        txtBtnOriginal.innerText = "+";
    }
}


function explainAguacates() {
    var textoAguacates = document.getElementById("explainAguacate");
    if (textoAguacates.innerText === "") {
        textoAguacates.innerText = explicacionAguacates;
    } else {
        textoAguacates.innerText = "";
    }
    
}

function btnAvo () {
    var txtBtnOriginal = document.getElementById("botonAguacate");
    if (txtBtnOriginal.innerText === "+") {
        txtBtnOriginal.innerText = txtBtnDown;
    } else {
        txtBtnOriginal.innerText = "+";
    }
}

function explainTshirt () {
    var textoCamisetas = document.getElementById("explainTshirt");
    if (textoCamisetas.innerText === "") {
        textoCamisetas.innerText = explicacionCamisetas;
    } else {
        textoCamisetas.innerText = "";
    }
}

function btnCam () {
    var txtBtnOriginal = document.getElementById("botonTshirt");
    if (txtBtnOriginal.innerText === "+") {
        txtBtnOriginal.innerText = txtBtnDown;
    } else {
        txtBtnOriginal.innerText = "+";
    }
}

function explainBitcoin () {
    var textoBitcoin = document.getElementById("explainBitcoin");
    if (textoBitcoin.innerText === "") {
        textoBitcoin.innerText = explicacionBitcoin;
    } else {
        textoBitcoin.innerText = "";
    }
}

function btnBic () {
    var txtBtnOriginal = document.getElementById("botonBitcoin");
    if (txtBtnOriginal.innerText === "+") {
        txtBtnOriginal.innerText = txtBtnDown;
    } else {
        txtBtnOriginal.innerText = "+";
    }
}

function explainTv () {
    var textoTv = document.getElementById("explainTv");
    if (textoTv.innerText === "") {
        textoTv.innerText = explicacionTV;
    } else {
        textoTv.innerText = "";
    }
}

function btnTv () {
    var txtBtnOriginal = document.getElementById("botonTv");
    if (txtBtnOriginal.innerText === "+") {
        txtBtnOriginal.innerText = txtBtnDown;
    } else {
        txtBtnOriginal.innerText = "+";
    }
}

function explainViajes () {
    var textoViajes = document.getElementById("explainViajes");
    if (textoViajes.innerText === "") {
        textoViajes.innerText = explicacionViajes;
    } else {
        textoViajes.innerText = "";
    }
}

function btnViaj () {
    var txtBtnOriginal = document.getElementById("botonViajes");
    if (txtBtnOriginal.innerText === "+") {
        txtBtnOriginal.innerText = txtBtnDown;
    } else {
        txtBtnOriginal.innerText = "+";
    }
}

var buttons = document.querySelectorAll("button");

buttons[0].addEventListener("click", calcularCO2);

buttons[1].addEventListener("click", explainAguacates);
buttons[1].addEventListener("click", btnAvo);

buttons[2].addEventListener("click", explainArboles);
buttons[2].addEventListener("click", btnArb);

buttons[3].addEventListener("click", explainTshirt);
buttons[3].addEventListener("click", btnCam);

buttons[4].addEventListener("click", explainBitcoin);
buttons[4].addEventListener("click", btnBic);

buttons[5].addEventListener("click", explainTv);
buttons[5].addEventListener("click", btnTv);

buttons[6].addEventListener("click", explainViajes);
buttons[6].addEventListener("click", btnViaj);